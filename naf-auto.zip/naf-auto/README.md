# NAF AUTO — Gestion Atelier

Application de gestion pour garage automobile.

## Déploiement sur Vercel (10 minutes)

### Étape 1 — Créer les comptes gratuits
1. Va sur **github.com** → créer un compte
2. Va sur **vercel.com** → créer un compte avec GitHub

### Étape 2 — Obtenir une clé API Anthropic
1. Va sur **aistudio.google.com**
2. Crée un compte et va dans "API Keys"
3. Crée une clé → copie-la (commence par `AIza...`)

### Étape 3 — Déployer
1. Va sur **vercel.com/new**
2. Clique "Import Git Repository" → connecte GitHub
3. Ou clique **"Deploy with template"** et drag & drop ce dossier
4. Dans les paramètres du projet → **Environment Variables** → ajoute :
   - Nom : `GEMINI_API_KEY`
   - Valeur : ta clé `AIza...`
5. Clique **Deploy**
6. Ton site est live sur `nafauto.vercel.app` !

### Étape 4 — Partager à l'équipe
- Envoie le lien à Aymen, Narek, Abi, Ahmed, Djihad, Isma, Yassine
- Sur iPhone : **Partager → Ajouter à l'écran d'accueil**

## Développement local
```bash
npm install
npm run dev
```

## Stack
- React 18 + Vite
- Vercel (hébergement + serverless functions)
- API Anthropic Claude (scan de devis)
- localStorage (données persistantes)
