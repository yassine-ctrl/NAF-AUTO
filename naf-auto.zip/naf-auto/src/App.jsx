import { useState, useEffect, useRef, useCallback } from "react";

/* ── COLORS ── */
const C = {
  bg:'#07080A', s1:'#0E0F12', s2:'#141519', s3:'#1A1B20',
  border:'#222428', dim:'#2A2B31',
  red:'#E8380D', redL:'rgba(232,56,13,0.09)',
  amber:'#F0A500', green:'#00C47A', blue:'#2D8EFF', cyan:'#00B8D9', purple:'#9D6EF5',
  text:'#ECEDF0', sub:'#72757E', faint:'#3A3B42',
};

const SEED = {
  bridges: [
    { id:'b1', name:'Pont Parallélisme', short:'Para.', note:'Géométrie & toutes interventions', status:'free',     jobId:null },
    { id:'b2', name:'Pont 2', short:'P2', note:'Interventions générales', status:'occupied', jobId:'j1' },
    { id:'b3', name:'Pont 3', short:'P3', note:'Interventions générales', status:'occupied', jobId:'j2' },
    { id:'b4', name:'Pont 4', short:'P4', note:'Interventions générales', status:'free',     jobId:null },
  ],
  employees: [
    { id:'aymen',   name:'Aymen',   role:'Mécanicien',        dept:'atelier', status:'available', schedule:{ am:'09:00–12:30', pm:'13:30–18:00', flex:false } },
    { id:'narek',   name:'Narek',   role:'Mécanicien',        dept:'atelier', status:'available', schedule:{ am:'09:00–12:30', pm:'13:30–18:00', flex:false } },
    { id:'abi',     name:'Abi',     role:'Mécanicien',        dept:'atelier', status:'busy',      schedule:{ am:'09:00–12:30', pm:'13:30–16:30', flex:false } },
    { id:'ahmed',   name:'Ahmed',   role:'Mécanicien',        dept:'atelier', status:'available', schedule:{ am:'09:00–12:30', pm:'13:30–18:30', flex:false } },
    { id:'djihad',  name:'Djihad',  role:'Atelier & Accueil', dept:'both',    status:'available', schedule:{ am:'08:30–12:30', pm:'13:30–18:00', flex:false } },
    { id:'isma',    name:'Isma',    role:'Patron',            dept:'patron',  status:'available', schedule:{ flex:true } },
    { id:'yassine', name:'Yassine', role:'Accueil / Patron',  dept:'accueil', status:'available', schedule:{ flex:true } },
  ],
  appointments: [
    { id:'a1', client:'Pierre Leblanc',    phone:'418-555-0123', email:'p.leblanc@gmail.com',    vehicle:'Honda Civic 2019',    plate:'ABC-1234', reason:'Vidange + inspection', time:'08:00', status:'in_progress', jobId:'j1', dossier:[] },
    { id:'a2', client:'Marie Bouchard',    phone:'418-555-0456', email:'m.bouchard@hotmail.com', vehicle:'Toyota RAV4 2021',    plate:'XYZ-5678', reason:'Bruits de freins',     time:'09:30', status:'in_progress', jobId:'j2', dossier:[] },
    { id:'a3', client:'Jean-François Roy', phone:'418-555-0789', email:'jf.roy@gmail.com',       vehicle:'Ford F-150 2020',     plate:'DEF-9012', reason:'Check engine light',   time:'10:00', status:'scheduled',   jobId:null, dossier:[] },
    { id:'a4', client:'Lucie Martin',      phone:'418-555-0321', email:'lucie.martin@yahoo.ca',  vehicle:'Hyundai Elantra 2018',plate:'GHI-3456', reason:'Pneus + alignement',  time:'13:00', status:'scheduled',   jobId:null, dossier:[] },
    { id:'a5', client:'Robert Simard',     phone:'418-555-0654', email:'r.simard@videotron.ca',  vehicle:'Mazda CX-5 2022',     plate:'JKL-7890', reason:'Vidange',             time:'11:00', status:'ready',       jobId:'j3', dossier:[
      { id:'d1', ref:'MO1314ED', libelle:'TAUX HORAIRE MO DIAG ELECTRONIC PAR 1/2', qte:2, pu:50.55, total:101.10, type:'mo' },
      { id:'d2', ref:'5PK1355',  libelle:'COURROIE MICRO V VL',                     qte:1, pu:45.00, total:45.00,  type:'piece' },
      { id:'d3', ref:'PROTECTC', libelle:'PARTICIPATION ENERGIE',                   qte:1, pu:3.50,  total:3.50,   type:'autre' },
    ]},
  ],
  jobs: [
    { id:'j1', apptId:'a1', bridgeId:'b2', techId:'aymen', status:'inspection', startTime:'08:15',
      findings:[
        { id:'f1', desc:'Filtre à air très encrassé — remplacement recommandé', status:'pending', photo:null },
        { id:'f2', desc:'Plaquettes de frein avant usées à 20%',                status:'pending', photo:null },
      ]},
    { id:'j2', apptId:'a2', bridgeId:'b3', techId:'narek', status:'in_progress', startTime:'09:45',
      findings:[
        { id:'f3', desc:'Disques de frein avant à remplacer',  status:'approved', photo:null },
        { id:'f4', desc:'Liquide de frein dégradé',            status:'approved', photo:null },
        { id:'f5', desc:"Filtre d'habitacle encrassé",         status:'noted',    photo:null },
      ]},
    { id:'j3', apptId:'a5', bridgeId:null, techId:null, status:'ready', startTime:'11:00', findings:[] },
  ],
  tasks: [
    { id:'t1', title:'Rangement pneus hiver — section B', cat:'org',   prio:'medium', assignedTo:null,  status:'pending' },
    { id:'t2', title:'Nettoyage Pont 1 (parallélisme)',   cat:'clean', prio:'low',    assignedTo:null,  status:'pending' },
    { id:'t3', title:'Inventaire huiles 5W-30 / 5W-40',  cat:'inv',   prio:'high',   assignedTo:'abi', status:'in_progress' },
    { id:'t4', title:'Commander filtres à air',           cat:'inv',   prio:'high',   assignedTo:null,  status:'pending' },
    { id:'t5', title:'Calibrer machine à équilibrage',    cat:'maint', prio:'medium', assignedTo:null,  status:'pending' },
  ],
  breaks: {},
};

const BREAK_SEC = 15 * 60;
const SYNC_INTERVAL = 3000;
const STORAGE_KEY = 'naf:state:v3';

const APPT_STATUS = { scheduled:'Prévu', arrived:'Arrivé', inspection:'Inspection', in_progress:'En travaux', ready:'Prête ✓', no_work:'Sans travaux', completed:'Complétée' };
const APPT_C = { scheduled:C.blue, arrived:C.purple, inspection:C.amber, in_progress:C.red, ready:C.green, no_work:C.sub, completed:C.faint };
const BR_C = { free:C.green, occupied:C.red, reserved:C.amber };
const BR_L = { free:'Libre', occupied:'Occupé', reserved:'Réservé' };
const PRIO_C = { high:C.red, medium:C.amber, low:C.sub };
const TASK_CAT = { org:{l:'Organisation',e:'📦'}, clean:{l:'Nettoyage',e:'🧹'}, inv:{l:'Inventaire',e:'📊'}, maint:{l:'Maintenance',e:'⚙️'} };
const FIND_C = { pending:C.amber, approved:C.green, declined:C.red, noted:C.cyan };
const FIND_L = { pending:'En attente', approved:'Approuvé', declined:'Refusé', noted:'Prochain RDV' };
const TYPE_C = { mo:C.blue, piece:C.cyan, autre:C.sub };
const TYPE_L = { mo:'Main d\'œuvre', piece:'Pièce', autre:'Autre' };

const uid = () => Math.random().toString(36).slice(2,7);
const fmtSec = s => `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;
const nowHHMM = () => { const d=new Date(); return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`; };
const isAM = () => new Date().getHours() < 12;
const fmt$ = n => `${Number(n).toFixed(2)} $`;

/* ── UI COMPONENTS ── */
function Badge({ label, color, small }) {
  return <span style={{ background:`${color}1A`, color, border:`1px solid ${color}40`, borderRadius:3, padding:small?'2px 7px':'3px 9px', fontSize:small?10:11, fontWeight:800, letterSpacing:.5, whiteSpace:'nowrap' }}>{label}</span>;
}
function Btn({ children, onClick, v='primary', sm, disabled, full, style }) {
  const base = { border:'none', borderRadius:6, fontFamily:'inherit', fontWeight:800, cursor:disabled?'not-allowed':'pointer', letterSpacing:.3, transition:'all .12s', opacity:disabled?.45:1, ...(full?{width:'100%'}:{}), ...style };
  const vs = {
    primary: { background:C.red,   color:'#fff',   padding:sm?'8px 14px':'10px 20px', fontSize:sm?12:14, boxShadow:`0 2px 10px ${C.red}44` },
    ghost:   { background:'transparent', color:C.sub, border:`1px solid ${C.border}`, padding:sm?'7px 13px':'9px 19px', fontSize:sm?12:14 },
    success: { background:`${C.green}18`, color:C.green, border:`1px solid ${C.green}44`, padding:sm?'7px 13px':'9px 19px', fontSize:sm?12:14 },
    danger:  { background:`${C.red}18`,   color:C.red,   border:`1px solid ${C.red}44`,   padding:sm?'7px 13px':'9px 19px', fontSize:sm?12:14 },
    amber:   { background:`${C.amber}18`, color:C.amber, border:`1px solid ${C.amber}44`, padding:sm?'7px 13px':'9px 19px', fontSize:sm?12:14 },
    blue:    { background:`${C.blue}18`,  color:C.blue,  border:`1px solid ${C.blue}44`,  padding:sm?'7px 13px':'9px 19px', fontSize:sm?12:14 },
  };
  return <button style={{...base,...vs[v]}} onClick={onClick} disabled={disabled}>{children}</button>;
}
function Input({ value, onChange, placeholder, type='text', style }) {
  return <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
    style={{ background:C.s3, border:`1px solid ${C.border}`, borderRadius:6, color:C.text, padding:'11px 14px', fontFamily:'inherit', fontSize:14, width:'100%', outline:'none', boxSizing:'border-box', ...style }}
    onFocus={e=>e.target.style.borderColor=C.red} onBlur={e=>e.target.style.borderColor=C.border}/>;
}
function Sel({ value, onChange, children, style }) {
  return <select value={value} onChange={e=>onChange(e.target.value)}
    style={{ background:C.s3, border:`1px solid ${C.border}`, borderRadius:6, color:C.text, padding:'11px 14px', fontFamily:'inherit', fontSize:14, outline:'none', cursor:'pointer', width:'100%', ...style }}>
    {children}
  </select>;
}
function Lbl({ c }) { return <div style={{ fontSize:11, color:C.sub, fontWeight:800, letterSpacing:1, marginBottom:6, textTransform:'uppercase' }}>{c}</div>; }
function Card({ children, style }) { return <div style={{ background:C.s1, border:`1px solid ${C.border}`, borderRadius:10, padding:14, ...style }}>{children}</div>; }
function Divider() { return <div style={{ height:1, background:C.border, margin:'12px 0' }}/>; }
function ST({ children }) { return <div style={{ fontSize:11, fontWeight:800, color:C.sub, letterSpacing:1.2, marginBottom:10, textTransform:'uppercase' }}>{children}</div>; }

function Toast({ msg, type='success' }) {
  const col = type==='success'?C.green:type==='error'?C.red:C.amber;
  return <div style={{ position:'fixed', bottom:24, left:'50%', transform:'translateX(-50%)', background:C.s2, color:col, padding:'12px 20px', borderRadius:99, fontWeight:800, fontSize:13, zIndex:9999, boxShadow:'0 6px 30px rgba(0,0,0,.7)', display:'flex', gap:8, alignItems:'center', border:`1px solid ${col}44`, whiteSpace:'nowrap' }}>
    <span>{type==='success'?'✓':type==='error'?'✕':'!'}</span><span>{msg}</span>
  </div>;
}

function Modal({ title, children, onClose, wide }) {
  return <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.88)', zIndex:1000, display:'flex', alignItems:'flex-end', justifyContent:'center' }}
    onClick={e=>e.target===e.currentTarget&&onClose()}>
    <div style={{ background:C.s1, border:`1px solid ${C.border}`, borderRadius:'16px 16px 0 0', width:'100%', maxWidth:wide?700:600, maxHeight:'92vh', overflowY:'auto', padding:20, paddingBottom:40 }}>
      <div style={{ width:40, height:4, background:C.dim, borderRadius:99, margin:'0 auto 18px' }}/>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
        <div style={{ fontSize:17, fontWeight:900, color:C.text }}>{title}</div>
        <button onClick={onClose} style={{ background:C.s3, border:`1px solid ${C.border}`, color:C.sub, borderRadius:6, width:32, height:32, cursor:'pointer', fontSize:18, display:'flex', alignItems:'center', justifyContent:'center' }}>×</button>
      </div>
      {children}
    </div>
  </div>;
}

/* ── AI TRANSCRIPTION ── */
async function transcribeDevis(base64Image) {
  const response = await fetch('/api/transcribe', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ imageBase64: base64Image }),
  });

  const data = await response.json();
  if (!response.ok || data.error) throw new Error(data.error || `Erreur ${response.status}`);

  const raw = (data.text || '').trim();

  let arr = null;
  try { const p = JSON.parse(raw); arr = Array.isArray(p) ? p : (p && p.items) || null; } catch(e) {}
  if (!arr) {
    const stripped = raw.replace(/^```(?:json)?\n?/i, '').replace(/\n?```$/, '').trim();
    try { const p = JSON.parse(stripped); arr = Array.isArray(p) ? p : (p && p.items) || null; } catch(e) {}
  }
  if (!arr) {
    const m = raw.match(/\[[\s\S]*\]/);
    if (m) try { const p = JSON.parse(m[0]); if (Array.isArray(p)) arr = p; } catch(e) {}
  }

  if (!arr || !arr.length) throw new Error('Aucune ligne extraite. Photo plus nette SVP.');
  return { items: arr };
}

/* ─── DOSSIER MODAL ─── */
function DossierModal({ appt, onClose, onSave }) {
  const [items, setItems] = useState(appt.dossier || []);
  const [scanning, setScanning] = useState(false);
  const [scanPreview, setScanPreview] = useState(null);
  const [scanError, setScanError] = useState(null);
  const [manualItem, setManualItem] = useState({ ref:'', libelle:'', qte:'1', pu:'', type:'piece' });
  const [showManual, setShowManual] = useState(false);
  const fileRef = useRef();

  // Convert any image to small JPEG via canvas
  const compressImage = (file) => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = (ev) => {
      const img = new Image();
      img.onerror = () => reject(new Error('Image illisible'));
      img.onload = () => {
        const MAX = 800;
        let w = img.width, h = img.height;
        if(w > MAX || h > MAX) {
          if(w > h) { h = Math.round(h * MAX / w); w = MAX; }
          else { w = Math.round(w * MAX / h); h = MAX; }
        }
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        canvas.getContext('2d').drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', 0.7));
      };
      img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
  });

  const handlePhotoScan = async (e) => {
    const file = e.target.files[0];
    if(!file) return;
    setScanError(null); setScanPreview(null); setScanning(true);
    try {
      const dataUrl = await compressImage(file);
      setScanPreview(dataUrl);
      const base64 = dataUrl.split(',')[1];
      const result = await transcribeDevis(base64);
      const newItems = (result.items || []).map(i => ({ ...i, id:'d'+uid() }));
      if(newItems.length === 0) {
        setScanError('Aucune ligne détectée — cadre bien sur le tableau des lignes.');
      } else {
        setItems(prev => [...prev, ...newItems]);
      }
    } catch(err) {
      setScanError('Erreur: ' + err.message);
    }
    setScanning(false);
    // Reset input so same file can be re-selected
    if(fileRef.current) fileRef.current.value = '';
  };

  const total = items.reduce((s, i) => s + (Number(i.total) || 0), 0);
  const totalHT = (total / 1.15).toFixed(2);

  const handleImportPaste = (raw) => {
    setScanError(null);
    if(!raw.trim()) return;
    try {
      // Accept full JSON object or bare array
      let parsed;
      const trimmed = raw.trim();
      if(trimmed.startsWith('[')) {
        parsed = JSON.parse(trimmed);
      } else {
        const obj = JSON.parse(trimmed);
        parsed = obj.items || obj;
      }
      if(!Array.isArray(parsed) || parsed.length === 0) throw new Error('Liste vide');
      const newItems = parsed.map(i => ({ ref:'', libelle:'', qte:1, pu:0, total:0, type:'piece', ...i, id:'d'+uid() }));
      setItems(prev => [...prev, ...newItems]);
      setImportText('');
      setShowImport(false);
    } catch(err) {
      setScanError('Format invalide — copie exactement le JSON donné par Claude.');
    }
  };

  const addManual = () => {
    if(!manualItem.libelle) return;
    const qte = Number(manualItem.qte) || 1;
    const pu = Number(manualItem.pu) || 0;
    setItems(prev => [...prev, { id:'d'+uid(), ref:manualItem.ref, libelle:manualItem.libelle, qte, pu, total:qte*pu, type:manualItem.type }]);
    setManualItem({ ref:'', libelle:'', qte:'1', pu:'', type:'piece' });
    setShowManual(false);
  };

  const removeItem = (id) => setItems(prev => prev.filter(i => i.id !== id));

  const editItem = (id, field, val) => {
    setItems(prev => prev.map(i => {
      if(i.id !== id) return i;
      const updated = { ...i, [field]: field==='ref'||field==='libelle'||field==='type' ? val : Number(val)||0 };
      if(field==='qte'||field==='pu') updated.total = (updated.qte||0) * (updated.pu||0);
      return updated;
    }));
  };

  return (
    <Modal title={`Dossier — ${appt.client}`} onClose={onClose} wide>
      {/* Vehicle info */}
      <div style={{ background:C.s2, borderRadius:8, padding:'10px 14px', marginBottom:16, display:'flex', gap:10, alignItems:'center' }}>
        <span style={{ fontSize:20 }}>🚗</span>
        <div>
          <div style={{ fontSize:14, fontWeight:800, color:C.text }}>{appt.vehicle} · {appt.plate}</div>
          <div style={{ fontSize:12, color:C.amber }}>{appt.reason}</div>
        </div>
      </div>

      {/* Scan + Manual buttons */}
      <div style={{ display:'flex', gap:8, marginBottom:14 }}>
        <button onClick={() => fileRef.current?.click()} disabled={scanning}
          style={{ flex:1, background:scanning?C.s3:`${C.blue}18`, border:`2px dashed ${C.blue}44`, borderRadius:10, padding:'14px', display:'flex', alignItems:'center', justifyContent:'center', gap:10, cursor:scanning?'not-allowed':'pointer', color:C.blue, fontFamily:'inherit', fontWeight:800, fontSize:13, opacity:scanning?.6:1 }}>
          {scanning ? <><Spinner/><span>Analyse en cours…</span></> : <><span style={{fontSize:22}}>📷</span><span>Scanner un devis</span></>}
        </button>
        <Btn sm v='ghost' onClick={() => setShowManual(p => !p)}>+ Manuel</Btn>
        <input ref={fileRef} type="file" accept="image/*" capture="environment" style={{display:'none'}} onChange={handlePhotoScan}/>
      </div>

      {/* Scan preview */}
      {scanPreview && (
        <div style={{ marginBottom:12, borderRadius:8, overflow:'hidden', border:`1px solid ${C.border}` }}>
          <img src={scanPreview} alt="scan" style={{ width:'100%', maxHeight:160, objectFit:'cover', display:'block' }}/>
        </div>
      )}

      {/* Error */}
      {scanError && <div style={{ background:`${C.red}15`, border:`1px solid ${C.red}33`, borderRadius:8, padding:'10px 14px', marginBottom:14, fontSize:13, color:C.red }}>{scanError}</div>}

      {/* Manual entry */}
      {showManual && (
        <div style={{ background:C.s2, borderRadius:8, padding:14, marginBottom:14 }}>
          <div style={{ fontSize:13, fontWeight:800, color:C.text, marginBottom:10 }}>Ajouter une ligne manuellement</div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:8 }}>
            <div><Lbl c="Référence"/><Input value={manualItem.ref} onChange={v=>setManualItem(p=>({...p,ref:v}))} placeholder="MO1314ED"/></div>
            <div><Lbl c="Type"/>
              <Sel value={manualItem.type} onChange={v=>setManualItem(p=>({...p,type:v}))}>
                <option value='piece'>Pièce</option>
                <option value='mo'>Main d'œuvre</option>
                <option value='autre'>Autre</option>
              </Sel>
            </div>
          </div>
          <div style={{ marginBottom:8 }}><Lbl c="Description *"/><Input value={manualItem.libelle} onChange={v=>setManualItem(p=>({...p,libelle:v}))} placeholder="COURROIE MICRO V VL"/></div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:10 }}>
            <div><Lbl c="Qté"/><Input type="number" value={manualItem.qte} onChange={v=>setManualItem(p=>({...p,qte:v}))} placeholder="1"/></div>
            <div><Lbl c="PU TTC ($)"/><Input type="number" value={manualItem.pu} onChange={v=>setManualItem(p=>({...p,pu:v}))} placeholder="0.00"/></div>
          </div>
          <Btn sm onClick={addManual} disabled={!manualItem.libelle}>Ajouter la ligne</Btn>
        </div>
      )}

      {/* Items table */}
      {items.length > 0 ? (
        <div style={{ marginBottom:16 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
            <ST>Lignes ({items.length})</ST>
            <span style={{ fontSize:11, color:C.sub }}>Appuyer sur une valeur pour modifier</span>
          </div>
          {items.map((item, idx) => (
            <div key={item.id} style={{ background:C.s2, borderRadius:8, padding:'10px 12px', marginBottom:8, border:`1px solid ${TYPE_C[item.type]}22` }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:6 }}>
                <div style={{ flex:1 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:3, flexWrap:'wrap' }}>
                    {item.ref && <span style={{ fontSize:11, fontWeight:900, color:TYPE_C[item.type], background:`${TYPE_C[item.type]}18`, padding:'2px 7px', borderRadius:3, fontFamily:'monospace' }}>{item.ref}</span>}
                    <Badge label={TYPE_L[item.type]} color={TYPE_C[item.type]} small/>
                  </div>
                  <div style={{ fontSize:13, color:C.text, lineHeight:1.4 }}>{item.libelle}</div>
                </div>
                <button onClick={() => removeItem(item.id)} style={{ background:'none', border:'none', color:C.faint, cursor:'pointer', fontSize:16, padding:'0 0 0 8px', flexShrink:0 }}>×</button>
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6 }}>
                {[
                  { l:'Qté', f:'qte', v:item.qte },
                  { l:'PU TTC', f:'pu', v:item.pu },
                  { l:'Total TTC', f:'total', v:item.total },
                ].map(({ l, f, v }) => (
                  <div key={f}>
                    <div style={{ fontSize:10, color:C.sub, marginBottom:2 }}>{l}</div>
                    <input value={v} onChange={e=>editItem(item.id,f,e.target.value)} type="number"
                      style={{ background:C.s3, border:`1px solid ${C.border}`, borderRadius:4, color:f==='total'?C.amber:C.text, padding:'5px 8px', fontFamily:'monospace', fontSize:13, fontWeight:700, width:'100%', outline:'none', boxSizing:'border-box' }}
                      onFocus={e=>e.target.style.borderColor=C.red} onBlur={e=>e.target.style.borderColor=C.border}/>
                  </div>
                ))}
              </div>
            </div>
          ))}

          {/* Total bar */}
          <div style={{ background:C.s3, borderRadius:8, padding:'12px 14px', display:'flex', justifyContent:'space-between', alignItems:'center', border:`1px solid ${C.border}` }}>
            <div>
              <div style={{ fontSize:11, color:C.sub }}>Sous-total HT (estimé)</div>
              <div style={{ fontSize:15, fontWeight:800, color:C.text }}>{totalHT} $</div>
            </div>
            <div style={{ textAlign:'right' }}>
              <div style={{ fontSize:11, color:C.sub }}>TOTAL TTC</div>
              <div style={{ fontSize:22, fontWeight:900, color:C.amber }}>{fmt$(total)}</div>
            </div>
          </div>
        </div>
      ) : (
        <div style={{ textAlign:'center', padding:'30px 20px', color:C.sub, background:C.s2, borderRadius:10, marginBottom:16 }}>
          <div style={{ fontSize:32, marginBottom:8, opacity:.4 }}>📋</div>
          <div style={{ fontSize:13 }}>Aucune ligne — scannez un devis ou ajoutez manuellement</div>
        </div>
      )}

      <div style={{ display:'flex', gap:8 }}>
        <Btn full onClick={() => onSave(items)}>💾 Sauvegarder le dossier</Btn>
        <Btn v='ghost' onClick={onClose}>Annuler</Btn>
      </div>
    </Modal>
  );
}

function Spinner() {
  return <div style={{ width:16, height:16, border:`2px solid ${C.blue}33`, borderTop:`2px solid ${C.blue}`, borderRadius:'50%', animation:'spin .7s linear infinite', flexShrink:0 }}/>;
}

/* ════════════════════════════════
   MAIN APP
════════════════════════════════ */
export default function NafAuto() {
  const [ready, setReady]         = useState(false);
  const [syncing, setSyncing]     = useState(false);
  const [lastSync, setLastSync]   = useState(null);
  const [tab, setTab]             = useState('dashboard');
  const [state, setState]         = useState(SEED);
  const [selJobId, setSelJobId]   = useState(null);
  const [dossierAppt, setDA]      = useState(null);
  const [toast, setToast]         = useState(null);
  const [modal, setModal]         = useState(null);
  const [now, setNow]             = useState(nowHHMM());
  const [nAppt, setNA]   = useState({ client:'', phone:'', email:'', vehicle:'', plate:'', reason:'', time:'' });
  const [nFind, setNF]   = useState({ desc:'', photo:null, photoURL:null });
  const [nTask, setNT]   = useState({ title:'', cat:'clean', prio:'medium' });
  const [sendCtx, setSC] = useState(null);
  const photoRef = useRef();
  const pendingWrite = useRef(false);
  const localVersion = useRef(0);

  const { bridges, employees, appointments, jobs, tasks, breaks } = state;
  const showToast = (msg, type='success') => { setToast({ msg, type }); setTimeout(() => setToast(null), 2800); };

  /* ── STORAGE ── */
  const saveState = useCallback(async (ns) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...ns, _v: Date.now() }));
      setLastSync(nowHHMM());
    } catch(e) {}
  }, []);

  const updateState = useCallback((updater) => {
    setState(prev => {
      const next = typeof updater === 'function' ? updater(prev) : updater;
      pendingWrite.current = true;
      saveState(next);
      return next;
    });
  }, [saveState]);

  useEffect(() => {
    (async () => {
      try {
        const res = { value: localStorage.getItem(STORAGE_KEY) };
        if(res?.value) {
          const parsed = JSON.parse(res.value);
          localVersion.current = parsed._v || 0;
          delete parsed._v;
          if(!parsed.breaks) parsed.breaks = {};
          // ensure dossier on all appts
          if(parsed.appointments) parsed.appointments = parsed.appointments.map(a => ({ dossier:[], ...a }));
          setState(parsed);
        }
      } catch(e) { await saveState(SEED); }
      setReady(true);
    })();
  }, [saveState]);

  useEffect(() => {
    if(!ready) return;
    const iv = setInterval(async () => {
      if(pendingWrite.current) { pendingWrite.current = false; return; }
      try {
        const res = { value: localStorage.getItem(STORAGE_KEY) };
        if(res?.value) {
          const parsed = JSON.parse(res.value);
          if(parsed._v && parsed._v > localVersion.current) {
            localVersion.current = parsed._v;
            delete parsed._v;
            if(!parsed.breaks) parsed.breaks = {};
            if(parsed.appointments) parsed.appointments = parsed.appointments.map(a => ({ dossier:[], ...a }));
            setSyncing(true);
            setState(parsed);
            setLastSync(nowHHMM());
            setTimeout(() => setSyncing(false), 600);
          }
        }
      } catch(e) {}
    }, SYNC_INTERVAL);
    return () => clearInterval(iv);
  }, [ready]);

  useEffect(() => {
    const iv = setInterval(() => {
      setState(prev => {
        const nb = { ...prev.breaks };
        let changed = false;
        Object.keys(nb).forEach(id => {
          if(nb[id]?.active) {
            const rem = nb[id].active.remaining - 1;
            if(rem <= 0) { const t = nb[id].active.type; nb[id] = { ...nb[id], active:null, [t==='am'?'amUsed':'pmUsed']:true }; }
            else nb[id] = { ...nb[id], active:{ ...nb[id].active, remaining:rem } };
            changed = true;
          }
        });
        if(!changed) return prev;
        const next = { ...prev, breaks: nb };
        saveState(next); return next;
      });
    }, 1000);
    return () => clearInterval(iv);
  }, [saveState]);

  useEffect(() => { const iv = setInterval(() => setNow(nowHHMM()), 15000); return () => clearInterval(iv); }, []);

  /* ── HELPERS ── */
  const getAppt  = id => appointments.find(a => a.id===id);
  const getJob   = id => jobs.find(j => j.id===id);
  const getEmp   = id => employees.find(e => e.id===id);
  const getBridge= id => bridges.find(b => b.id===id);
  const getBreak = id => breaks[id] || { amUsed:false, pmUsed:false, active:null };
  const canBreak = id => { const b=getBreak(id); if(b.active) return false; return isAM() ? !b.amUsed : !b.pmUsed; };
  const freeBridges   = bridges.filter(b => b.status==='free');
  const availableEmps = employees.filter(e => e.status==='available');
  const activeJobs    = jobs.filter(j => j.status!=='ready' && j.status!=='completed');
  const readyCount    = appointments.filter(a => a.status==='ready').length;
  const pendingTasks  = tasks.filter(t => t.status==='pending');

  /* ── ACTIONS ── */
  const markArrived = id => { updateState(p => ({ ...p, appointments: p.appointments.map(a => a.id===id?{...a,status:'arrived'}:a) })); showToast('Client arrivé'); };

  const assignBridge = (apptId, bridgeId) => {
    const appt = getAppt(apptId);
    const jId = 'j'+uid();
    updateState(p => ({
      ...p,
      jobs: [...p.jobs, { id:jId, apptId, bridgeId, techId:null, status:'inspection', startTime:nowHHMM(), findings:[] }],
      appointments: p.appointments.map(a => a.id===apptId?{...a,status:'inspection',jobId:jId}:a),
      bridges: p.bridges.map(b => b.id===bridgeId?{...b,status:'occupied',jobId:jId}:b),
    }));
    setSelJobId(jId); setTab('inspection');
    showToast(`${appt?.vehicle} → ${getBridge(bridgeId)?.name}`);
  };

  const addFinding = () => {
    if(!selJobId||!nFind.desc) return;
    updateState(p => ({ ...p, jobs: p.jobs.map(j => j.id===selJobId?{...j,findings:[...j.findings,{id:'f'+uid(),desc:nFind.desc,status:'pending',photo:nFind.photoURL}]}:j) }));
    setNF({ desc:'', photo:null, photoURL:null }); setModal(null); showToast('Constat ajouté');
  };

  const setFindSt = (jId, fId, st) => updateState(p => ({ ...p, jobs: p.jobs.map(j => j.id===jId?{...j,findings:j.findings.map(f=>f.id===fId?{...f,status:st}:f)}:j) }));

  const markReady = jId => {
    const job = getJob(jId);
    updateState(p => ({
      ...p,
      jobs: p.jobs.map(j => j.id===jId?{...j,status:'ready'}:j),
      appointments: p.appointments.map(a => a.id===job.apptId?{...a,status:'ready'}:a),
      bridges: job.bridgeId?p.bridges.map(b=>b.id===job.bridgeId?{...b,status:'free',jobId:null}:b):p.bridges,
    }));
    showToast('Voiture prête ✓');
  };

  const markNoWork = jId => {
    const job = getJob(jId);
    updateState(p => ({
      ...p,
      jobs: p.jobs.map(j => j.id===jId?{...j,status:'ready'}:j),
      appointments: p.appointments.map(a => a.id===job.apptId?{...a,status:'no_work'}:a),
      bridges: job.bridgeId?p.bridges.map(b=>b.id===job.bridgeId?{...b,status:'free',jobId:null}:b):p.bridges,
    }));
    showToast('Complétée sans travaux');
  };

  const saveDossier = (apptId, items) => {
    updateState(p => ({ ...p, appointments: p.appointments.map(a => a.id===apptId?{...a,dossier:items}:a) }));
    setDA(null); showToast('Dossier sauvegardé ✓');
  };

  const createAppt = () => {
    if(!nAppt.client||!nAppt.vehicle) return;
    updateState(p => ({ ...p, appointments: [...p.appointments,{id:'a'+uid(),...nAppt,status:'scheduled',jobId:null,dossier:[]}] }));
    setNA({ client:'', phone:'', email:'', vehicle:'', plate:'', reason:'', time:'' });
    setModal(null); showToast('RDV créé');
  };

  const addTask = () => {
    if(!nTask.title) return;
    updateState(p => ({ ...p, tasks:[...p.tasks,{id:'t'+uid(),...nTask,assignedTo:null,status:'pending'}] }));
    setNT({ title:'', cat:'clean', prio:'medium' }); setModal(null); showToast('Tâche ajoutée');
  };

  const assignTask = (tId, eId) => {
    updateState(p => ({
      ...p,
      tasks: p.tasks.map(t=>t.id===tId?{...t,assignedTo:eId,status:'in_progress'}:t),
      employees: p.employees.map(e=>e.id===eId?{...e,status:'busy'}:e),
    }));
    showToast(`Assigné à ${getEmp(eId)?.name}`);
  };

  const completeTask = tId => {
    const task = tasks.find(t=>t.id===tId);
    updateState(p => ({
      ...p,
      tasks: p.tasks.map(t=>t.id===tId?{...t,status:'done'}:t),
      employees: task?.assignedTo?p.employees.map(e=>e.id===task.assignedTo?{...e,status:'available'}:e):p.employees,
    }));
    showToast('Tâche complétée ✓');
  };

  const setEmpStatus = (eId, st) => updateState(p => ({ ...p, employees:p.employees.map(e=>e.id===eId?{...e,status:st}:e) }));
  const startBreak = eId => { const type=isAM()?'am':'pm'; updateState(p => ({...p,employees:p.employees.map(e=>e.id===eId?{...e,status:'break'}:e),breaks:{...p.breaks,[eId]:{...getBreak(eId),active:{type,remaining:BREAK_SEC}}}})); };
  const endBreak = eId => { const b=getBreak(eId),type=b.active?.type; updateState(p => ({...p,employees:p.employees.map(e=>e.id===eId?{...e,status:'available'}:e),breaks:{...p.breaks,[eId]:{...b,active:null,...(type?{[type==='am'?'amUsed':'pmUsed']:true}:{})}}})); };

  const handlePhoto = e => {
    const file=e.target.files[0]; if(!file) return;
    const reader=new FileReader();
    reader.onload=ev=>setNF(p=>({...p,photo:file,photoURL:ev.target.result}));
    reader.readAsDataURL(file);
  };

  const openSend = (finding, jId) => { const job=getJob(jId); setSC({finding,appt:job?getAppt(job.apptId):null}); setModal('send'); };
  const sendSMS = () => { if(!sendCtx) return; const{finding,appt}=sendCtx; window.open(`sms:${appt?.phone}?body=${encodeURIComponent(`NAF AUTO\n${appt?.vehicle} (${appt?.plate})\n\n🔧 ${finding.desc}\n\nContactez-nous pour confirmer.`)}`); showToast('SMS ouvert'); setModal(null); };
  const sendEmail = () => { if(!sendCtx) return; const{finding,appt}=sendCtx; window.open(`mailto:${appt?.email}?subject=${encodeURIComponent(`NAF AUTO — Constat ${appt?.plate}`)}&body=${encodeURIComponent(`Bonjour ${appt?.client},\n\nNous avons inspecté votre ${appt?.vehicle} (${appt?.plate}).\n\n🔧 Constat:\n${finding.desc}\n\nContactez-nous pour approuver.\n\nCordialement,\nNAF AUTO`)}`); showToast('Courriel ouvert'); setModal(null); };

  const NAV = [
    { id:'dashboard', label:'Dashboard', icon:'◈' },
    { id:'rdv',       label:'RDV',       icon:'◷' },
    { id:'atelier',   label:'Atelier',   icon:'⬡' },
    { id:'inspection',label:'Inspection',icon:'◎' },
    { id:'tasks',     label:'Tâches',    icon:'◻' },
    { id:'equipe',    label:'Équipe',    icon:'◉' },
  ];

  /* ════════ PAGES ════════ */

  const renderDashboard = () => (
    <div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:14}}>
        {[
          {l:"RDV aujourd'hui",v:appointments.length,c:C.blue,e:'◷'},
          {l:'En atelier',v:activeJobs.length,c:C.red,e:'⬡'},
          {l:'Prêtes',v:readyCount,c:C.green,e:'✓'},
          {l:'Ponts libres',v:freeBridges.length,c:C.cyan,e:'▲'},
          {l:'Dispo équipe',v:availableEmps.length,c:C.purple,e:'◉'},
          {l:'Tâches attente',v:pendingTasks.length,c:C.amber,e:'◻'},
        ].map(s=>(
          <Card key={s.l} style={{padding:14}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <div>
                <div style={{fontSize:28,fontWeight:900,color:s.c,fontFamily:'monospace',lineHeight:1}}>{s.v}</div>
                <div style={{fontSize:11,color:C.sub,marginTop:4,lineHeight:1.3}}>{s.l}</div>
              </div>
              <span style={{fontSize:22,color:s.c,opacity:.4}}>{s.e}</span>
            </div>
          </Card>
        ))}
      </div>
      <Card style={{marginBottom:14}}>
        <ST>Ponts</ST>
        {bridges.map(b=>{
          const job=b.jobId?getJob(b.jobId):null; const appt=job?getAppt(job.apptId):null;
          return <div key={b.id} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 12px',background:C.s2,borderRadius:8,border:`1px solid ${b.status==='occupied'?C.red+'33':C.border}`,marginBottom:7}}>
            <div style={{width:9,height:9,borderRadius:'50%',background:BR_C[b.status],flexShrink:0,boxShadow:`0 0 6px ${BR_C[b.status]}`}}/>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:13,fontWeight:800,color:C.text}}>{b.name}</div>
              {appt?<div style={{fontSize:11,color:C.sub,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{appt.vehicle} · {appt.client}</div>:<div style={{fontSize:11,color:C.sub}}>{b.note}</div>}
            </div>
            <Badge label={BR_L[b.status]} color={BR_C[b.status]} small/>
          </div>;
        })}
      </Card>
      <Card>
        <ST>Horaire du jour</ST>
        {appointments.map(a=>(
          <div key={a.id} style={{display:'flex',alignItems:'center',gap:10,padding:'9px 12px',background:C.s2,borderRadius:8,marginBottom:7}}>
            <div style={{fontSize:13,fontWeight:900,color:C.red,minWidth:44,fontFamily:'monospace'}}>{a.time}</div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:13,fontWeight:700,color:C.text,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{a.client}</div>
              <div style={{fontSize:11,color:C.sub,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{a.vehicle}</div>
            </div>
            {a.dossier?.length>0 && <span style={{fontSize:10,color:C.cyan,fontWeight:700,marginRight:4}}>{a.dossier.length}L</span>}
            <Badge label={APPT_STATUS[a.status]} color={APPT_C[a.status]} small/>
          </div>
        ))}
      </Card>
    </div>
  );

  const renderRDV = () => (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
        <div style={{fontSize:20,fontWeight:900,color:C.text}}>Rendez-vous</div>
        <Btn sm onClick={()=>setModal('addAppt')}>+ Nouveau</Btn>
      </div>
      {appointments.map(a=>{
        const dossierTotal = (a.dossier||[]).reduce((s,i)=>s+(Number(i.total)||0),0);
        return (
          <Card key={a.id} style={{marginBottom:10}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
              <span style={{fontSize:17,fontWeight:900,color:C.red,fontFamily:'monospace'}}>{a.time}</span>
              <Badge label={APPT_STATUS[a.status]} color={APPT_C[a.status]} small/>
            </div>
            <div style={{fontSize:16,fontWeight:800,color:C.text,marginBottom:2}}>{a.client}</div>
            <div style={{fontSize:13,color:C.sub,marginBottom:2}}>{a.vehicle} · <span style={{color:C.text,fontWeight:700}}>{a.plate}</span></div>
            <div style={{fontSize:12,color:C.sub,marginBottom:1}}>📞 {a.phone}</div>
            <div style={{fontSize:12,color:C.sub,marginBottom:8}}>✉ {a.email}</div>
            <div style={{fontSize:13,color:C.amber,fontWeight:600,marginBottom:12}}>→ {a.reason}</div>

            {/* Dossier preview */}
            {(a.dossier||[]).length > 0 && (
              <div style={{background:C.s2,borderRadius:8,padding:'10px 12px',marginBottom:12,border:`1px solid ${C.cyan}22`}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
                  <span style={{fontSize:11,fontWeight:800,color:C.cyan,letterSpacing:.8}}>📋 DOSSIER · {a.dossier.length} lignes</span>
                  <span style={{fontSize:14,fontWeight:900,color:C.amber}}>{fmt$(dossierTotal)}</span>
                </div>
                {a.dossier.slice(0,3).map(item=>(
                  <div key={item.id} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'4px 0',borderBottom:`1px solid ${C.border}`}}>
                    <div style={{flex:1,minWidth:0}}>
                      {item.ref && <span style={{fontSize:10,color:TYPE_C[item.type],fontFamily:'monospace',fontWeight:800,marginRight:6}}>{item.ref}</span>}
                      <span style={{fontSize:12,color:C.text}}>{item.libelle}</span>
                    </div>
                    <span style={{fontSize:12,color:C.amber,fontWeight:700,marginLeft:8,whiteSpace:'nowrap'}}>{fmt$(item.total)}</span>
                  </div>
                ))}
                {a.dossier.length > 3 && <div style={{fontSize:11,color:C.sub,marginTop:5,textAlign:'center'}}>+{a.dossier.length-3} autres lignes</div>}
              </div>
            )}

            <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
              {/* Dossier button — always visible */}
              <Btn sm v='blue' onClick={()=>setDA(a)}>
                {(a.dossier||[]).length>0 ? `📋 Dossier (${a.dossier.length})` : '📋 Dossier'}
              </Btn>
              {a.status==='scheduled' && <Btn sm onClick={()=>markArrived(a.id)}>Client arrivé</Btn>}
              {a.status==='arrived' && freeBridges.length===0 && <Badge label="Attente pont" color={C.amber}/>}
              {a.status==='arrived' && freeBridges.map(b=><Btn key={b.id} sm onClick={()=>assignBridge(a.id,b.id)}>→ {b.short||b.name}</Btn>)}
              {['inspection','in_progress'].includes(a.status) && a.jobId && <Btn sm v='ghost' onClick={()=>{setSelJobId(a.jobId);setTab('inspection');}}>Inspection →</Btn>}
              {a.status==='ready' && <Badge label="✓ Prête" color={C.green}/>}
            </div>
          </Card>
        );
      })}
    </div>
  );

  const renderAtelier = () => (
    <div>
      <div style={{fontSize:20,fontWeight:900,color:C.text,marginBottom:14}}>Atelier</div>
      {bridges.map(b=>{
        const job=b.jobId?getJob(b.jobId):null; const appt=job?getAppt(job.apptId):null; const tech=job?.techId?getEmp(job.techId):null;
        return <Card key={b.id} style={{border:`2px solid ${BR_C[b.status]}33`,marginBottom:12}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:10}}>
            <div>
              <div style={{display:'flex',alignItems:'center',gap:8}}>
                <div style={{width:9,height:9,borderRadius:'50%',background:BR_C[b.status],boxShadow:`0 0 6px ${BR_C[b.status]}`}}/>
                <span style={{fontSize:16,fontWeight:900,color:C.text}}>{b.name}</span>
              </div>
              <div style={{fontSize:11,color:C.sub,marginTop:3,paddingLeft:17}}>{b.note}</div>
            </div>
            <Badge label={BR_L[b.status]} color={BR_C[b.status]}/>
          </div>
          {b.status==='free'
            ? <div style={{textAlign:'center',padding:'14px 0',color:C.sub}}><div style={{fontSize:26}}>✅</div><div style={{fontSize:12,marginTop:4}}>Disponible</div></div>
            : appt&&job&&<>
                <div style={{background:C.s2,borderRadius:8,padding:'10px 12px',marginBottom:10}}>
                  <div style={{fontSize:15,fontWeight:800,color:C.text}}>{appt.vehicle}</div>
                  <div style={{fontSize:12,color:C.sub,marginTop:2}}>{appt.client} · {appt.plate}</div>
                  <div style={{fontSize:11,color:C.amber,marginTop:4}}>Depuis {job.startTime}</div>
                  {(appt.dossier||[]).length>0 && <div style={{fontSize:11,color:C.cyan,marginTop:4}}>📋 {appt.dossier.length} lignes au dossier</div>}
                </div>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:10}}>
                  <Badge label={APPT_STATUS[appt.status]} color={APPT_C[appt.status]}/>
                  {tech&&<span style={{fontSize:12,color:C.sub}}>👤 {tech.name}</span>}
                </div>
                <Btn sm full onClick={()=>{setSelJobId(job.id);setTab('inspection');}}>Ouvrir inspection →</Btn>
              </>
          }
        </Card>;
      })}
    </div>
  );

  const renderInspection = () => {
    const job=selJobId?getJob(selJobId):null; const appt=job?getAppt(job.apptId):null;
    if(!job) return <div style={{textAlign:'center',padding:'60px 20px',color:C.sub}}><div style={{fontSize:48,marginBottom:12,opacity:.3}}>◎</div><div style={{fontSize:16,fontWeight:700,color:C.text,marginBottom:6}}>Aucune inspection</div><div style={{fontSize:13}}>Sélectionnez un véhicule.</div></div>;
    const dossier = appt?.dossier||[];
    return <div>
      <Card style={{marginBottom:14}}>
        <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8,flexWrap:'wrap'}}>
          <span style={{fontSize:16,fontWeight:900,color:C.text}}>{appt?.vehicle}</span>
          <Badge label={appt?.plate||''} color={C.red}/>
          <Badge label={APPT_STATUS[appt?.status]} color={APPT_C[appt?.status]} small/>
        </div>
        <div style={{fontSize:13,color:C.sub,marginBottom:2}}>{appt?.client} · {appt?.phone}</div>
        <div style={{fontSize:13,color:C.amber,fontWeight:600,marginTop:6}}>→ {appt?.reason}</div>
        {dossier.length>0 && (
          <div style={{marginTop:8,background:C.s2,borderRadius:6,padding:'6px 10px',fontSize:12,color:C.cyan}}>
            📋 {dossier.length} ligne(s) au dossier · Total : {fmt$(dossier.reduce((s,i)=>s+(Number(i.total)||0),0))}
          </div>
        )}
        <Divider/>
        <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
          <Btn sm onClick={()=>setModal('addFinding')}>+ Constat</Btn>
          <Btn sm v='blue' onClick={()=>setDA(appt)}>📋 Dossier</Btn>
          {job.status!=='ready'&&<Btn sm v='success' onClick={()=>markReady(job.id)}>✓ Prête</Btn>}
          {job.status!=='ready'&&job.findings.length===0&&<Btn sm v='ghost' onClick={()=>markNoWork(job.id)}>Sans travaux</Btn>}
        </div>
      </Card>
      <ST>Constats ({job.findings.length})</ST>
      {job.findings.length===0&&<div style={{textAlign:'center',padding:'28px 16px',color:C.sub,background:C.s1,borderRadius:10,border:`1px dashed ${C.border}`,fontSize:13,marginBottom:14}}>Appuyez sur <strong style={{color:C.text}}>+ Constat</strong></div>}
      {job.findings.map(f=>(
        <Card key={f.id} style={{border:`1px solid ${f.status==='approved'?C.green+'44':f.status==='declined'?C.red+'33':C.border}`,marginBottom:10}}>
          {f.photo?<img src={f.photo} alt="constat" style={{width:'100%',height:160,objectFit:'cover',borderRadius:7,marginBottom:10}}/>:<div style={{width:'100%',height:70,background:C.s3,borderRadius:7,marginBottom:10,display:'flex',alignItems:'center',justifyContent:'center',fontSize:28,opacity:.4}}>📷</div>}
          <div style={{fontSize:14,color:C.text,marginBottom:8,lineHeight:1.5}}>{f.desc}</div>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:8,marginBottom:f.status==='pending'?10:0}}>
            <Badge label={FIND_L[f.status]} color={FIND_C[f.status]}/>
            <Btn sm v='ghost' onClick={()=>openSend(f,job.id)}>📤 Envoyer</Btn>
          </div>
          {f.status==='pending'&&<div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:7}}>
            <Btn sm v='success' full onClick={()=>setFindSt(job.id,f.id,'approved')}>✓ OK</Btn>
            <Btn sm v='amber'   full onClick={()=>setFindSt(job.id,f.id,'noted')}>+ Tard</Btn>
            <Btn sm v='danger'  full onClick={()=>setFindSt(job.id,f.id,'declined')}>Refusé</Btn>
          </div>}
        </Card>
      ))}
      {job.findings.length>0&&<Card style={{background:C.s2}}>
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:8,textAlign:'center'}}>
          {[{l:'Approuvés',v:job.findings.filter(f=>f.status==='approved').length,c:C.green},{l:'Attente',v:job.findings.filter(f=>f.status==='pending').length,c:C.amber},{l:'+ Tard',v:job.findings.filter(f=>f.status==='noted').length,c:C.cyan},{l:'Refusés',v:job.findings.filter(f=>f.status==='declined').length,c:C.sub}].map(s=>(
            <div key={s.l}><div style={{fontSize:22,fontWeight:900,color:s.c}}>{s.v}</div><div style={{fontSize:11,color:C.sub,marginTop:2}}>{s.l}</div></div>
          ))}
        </div>
      </Card>}
    </div>;
  };

  const renderTasks = () => (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
        <div style={{fontSize:20,fontWeight:900,color:C.text}}>Tâches</div>
        <Btn sm onClick={()=>setModal('addTask')}>+ Nouvelle</Btn>
      </div>
      {availableEmps.length>0&&<div style={{background:C.redL,border:`1px solid ${C.red}33`,borderRadius:8,padding:'10px 14px',marginBottom:14,fontSize:13,color:C.red,fontWeight:600}}>⚡ Dispo : {availableEmps.map(e=>e.name).join(', ')}</div>}
      {Object.keys(TASK_CAT).map(cat=>{
        const catT=tasks.filter(t=>t.cat===cat&&t.status!=='done'); if(!catT.length) return null;
        return <div key={cat} style={{marginBottom:16}}>
          <ST>{TASK_CAT[cat].e} {TASK_CAT[cat].l}</ST>
          {catT.map(t=>{const assignee=t.assignedTo?getEmp(t.assignedTo):null; return <Card key={t.id} style={{marginBottom:8}}>
            <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:(t.status==='pending'&&availableEmps.length>0)||t.status==='in_progress'?10:0}}>
              <div style={{width:7,height:7,borderRadius:'50%',background:PRIO_C[t.prio],flexShrink:0}}/>
              <div style={{flex:1}}><div style={{fontSize:14,fontWeight:700,color:C.text}}>{t.title}</div>{assignee&&<div style={{fontSize:12,color:C.cyan,marginTop:2}}>👤 {assignee.name}</div>}</div>
              <Badge label={t.prio} color={PRIO_C[t.prio]} small/>
            </div>
            {t.status==='pending'&&availableEmps.length>0&&<Sel value='' onChange={v=>v&&assignTask(t.id,v)} style={{fontSize:13,padding:'8px 12px'}}><option value=''>Assigner à…</option>{availableEmps.map(e=><option key={e.id} value={e.id}>{e.name}</option>)}</Sel>}
            {t.status==='in_progress'&&<Btn sm v='success' full onClick={()=>completeTask(t.id)}>✓ Marquer fait</Btn>}
          </Card>;})}
        </div>;
      })}
      {tasks.filter(t=>t.status==='done').length>0&&<>{<ST>✅ Complétées</ST>}{tasks.filter(t=>t.status==='done').map(t=><div key={t.id} style={{padding:'8px 12px',fontSize:13,color:C.faint,textDecoration:'line-through',borderRadius:6,background:C.s1,marginBottom:6}}>{t.title}</div>)}</>}
    </div>
  );

  const renderEquipe = () => {
    const stC={available:C.green,busy:C.red,break:C.amber}; const stL={available:'Disponible',busy:'En travaux',break:'En pause'};
    return <div>
      <div style={{fontSize:20,fontWeight:900,color:C.text,marginBottom:14}}>Équipe</div>
      {employees.map(e=>{
        const b=getBreak(e.id),isOnBreak=e.status==='break',sc=stC[e.status]||C.sub;
        const task=tasks.find(t=>t.assignedTo===e.id&&t.status==='in_progress');
        const empJob=jobs.find(j=>j.techId===e.id&&j.status!=='ready');
        const empAppt=empJob?getAppt(empJob.apptId):null;
        return <Card key={e.id} style={{border:`1px solid ${sc}30`,marginBottom:12}}>
          <div style={{display:'flex',gap:12,alignItems:'center',marginBottom:12}}>
            <div style={{width:46,height:46,borderRadius:'50%',background:`${sc}18`,border:`2px solid ${sc}`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:20,fontWeight:900,color:sc,flexShrink:0}}>{e.name.charAt(0)}</div>
            <div style={{flex:1}}><div style={{fontSize:16,fontWeight:900,color:C.text}}>{e.name}</div><div style={{fontSize:12,color:C.sub}}>{e.role}</div></div>
            <div style={{textAlign:'right'}}>
              <Badge label={stL[e.status]} color={sc}/>
              {isOnBreak&&b?.active&&<div style={{fontSize:16,fontWeight:900,color:C.amber,fontFamily:'monospace',marginTop:4}}>⏱ {fmtSec(b.active.remaining)}</div>}
            </div>
          </div>
          <div style={{background:C.s2,borderRadius:7,padding:'8px 12px',marginBottom:10}}>
            {e.schedule.flex?<span style={{fontSize:12,color:C.purple,fontWeight:700}}>⭐ Horaire flexible</span>:<div style={{fontSize:12,display:'flex',gap:10}}><span style={{color:C.sub}}>AM</span><span style={{color:C.text,fontFamily:'monospace',fontWeight:700}}>{e.schedule.am}</span><span style={{color:C.sub}}>PM</span><span style={{color:C.text,fontFamily:'monospace',fontWeight:700}}>{e.schedule.pm}</span></div>}
          </div>
          {empAppt&&<div style={{background:C.s3,borderRadius:6,padding:'7px 10px',fontSize:12,color:C.sub,marginBottom:8}}>🔧 {empAppt.vehicle} — {empAppt.reason}</div>}
          {task&&<div style={{background:C.s3,borderRadius:6,padding:'7px 10px',fontSize:12,color:C.sub,marginBottom:8}}>{TASK_CAT[task.cat]?.e} {task.title}</div>}
          {!e.schedule.flex&&<div style={{display:'flex',gap:7,marginBottom:10}}>
            {[['am','AM'],['pm','PM']].map(([k,l])=><div key={k} style={{flex:1,padding:5,borderRadius:5,background:b?.[k+'Used']?`${C.green}15`:`${C.amber}10`,border:`1px solid ${b?.[k+'Used']?C.green+'33':C.amber+'22'}`,fontSize:11,fontWeight:700,color:b?.[k+'Used']?C.green:C.sub,textAlign:'center'}}>{b?.[k+'Used']?`✓ Pause ${l}`:`○ Pause ${l}`}</div>)}
          </div>}
          <div style={{display:'flex',gap:7,flexWrap:'wrap'}}>
            <Btn sm v={e.status==='available'?'primary':'ghost'} onClick={()=>setEmpStatus(e.id,'available')}>Dispo</Btn>
            <Btn sm v={e.status==='busy'?'primary':'ghost'} onClick={()=>setEmpStatus(e.id,'busy')}>Travaux</Btn>
            {!e.schedule.flex&&(isOnBreak?<Btn sm v='amber' onClick={()=>endBreak(e.id)}>⏹ Fin pause</Btn>:canBreak(e.id)?<Btn sm v='amber' onClick={()=>startBreak(e.id)}>☕ Pause 15min</Btn>:<span style={{fontSize:11,color:C.faint,padding:'7px 8px'}}>Pause prise</span>)}
          </div>
        </Card>;
      })}
    </div>;
  };

  /* ── MODALS ── */
  const renderModal = () => {
    if(modal==='addAppt') return <Modal title="Nouveau RDV" onClose={()=>setModal(null)}>
      <div style={{display:'flex',flexDirection:'column',gap:12}}>
        <div><Lbl c="Client *"/><Input value={nAppt.client} onChange={v=>setNA(p=>({...p,client:v}))} placeholder="Nom complet"/></div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
          <div><Lbl c="Tél."/><Input value={nAppt.phone} onChange={v=>setNA(p=>({...p,phone:v}))} placeholder="514-555-0000"/></div>
          <div><Lbl c="Courriel"/><Input value={nAppt.email} onChange={v=>setNA(p=>({...p,email:v}))} placeholder="client@email.ca"/></div>
        </div>
        <div><Lbl c="Véhicule *"/><Input value={nAppt.vehicle} onChange={v=>setNA(p=>({...p,vehicle:v}))} placeholder="Honda Civic 2021"/></div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
          <div><Lbl c="Plaque"/><Input value={nAppt.plate} onChange={v=>setNA(p=>({...p,plate:v}))} placeholder="ABC-1234"/></div>
          <div><Lbl c="Heure"/><Input type="time" value={nAppt.time} onChange={v=>setNA(p=>({...p,time:v}))}/></div>
        </div>
        <div><Lbl c="Raison"/><Input value={nAppt.reason} onChange={v=>setNA(p=>({...p,reason:v}))} placeholder="Vidange, freins…"/></div>
        <div style={{display:'flex',gap:8}}><Btn full onClick={createAppt} disabled={!nAppt.client||!nAppt.vehicle}>Créer</Btn><Btn v='ghost' onClick={()=>setModal(null)}>Annuler</Btn></div>
      </div>
    </Modal>;

    if(modal==='addFinding') return <Modal title="Ajouter un constat" onClose={()=>setModal(null)}>
      <div style={{display:'flex',flexDirection:'column',gap:12}}>
        <div>
          <Lbl c="Photo"/>
          <div onClick={()=>photoRef.current?.click()} style={{border:`2px dashed ${C.border}`,borderRadius:10,padding:24,textAlign:'center',cursor:'pointer',background:C.s2}}>
            {nFind.photoURL?<img src={nFind.photoURL} alt="preview" style={{maxHeight:160,borderRadius:8,maxWidth:'100%'}}/>:<><div style={{fontSize:36,marginBottom:8,opacity:.4}}>📷</div><div style={{fontSize:13,color:C.sub}}>Prendre une photo</div></>}
          </div>
          <input ref={photoRef} type="file" accept="image/*" capture="environment" style={{display:'none'}} onChange={handlePhoto}/>
        </div>
        <div><Lbl c="Description *"/><textarea value={nFind.desc} onChange={e=>setNF(p=>({...p,desc:e.target.value}))} placeholder="Décrivez le problème…" style={{background:C.s3,border:`1px solid ${C.border}`,borderRadius:6,color:C.text,padding:'11px 14px',fontFamily:'inherit',fontSize:14,width:'100%',minHeight:100,outline:'none',boxSizing:'border-box',resize:'vertical'}} onFocus={e=>e.target.style.borderColor=C.red} onBlur={e=>e.target.style.borderColor=C.border}/></div>
        <div style={{display:'flex',gap:8}}><Btn full onClick={addFinding} disabled={!nFind.desc}>Ajouter</Btn><Btn v='ghost' onClick={()=>setModal(null)}>Annuler</Btn></div>
      </div>
    </Modal>;

    if(modal==='send'&&sendCtx) return <Modal title="Envoyer au client" onClose={()=>setModal(null)}>
      <div style={{background:C.s2,borderRadius:10,padding:14,marginBottom:18}}>
        <div style={{fontSize:14,fontWeight:700,color:C.text,marginBottom:10}}>{sendCtx.appt?.client} — {sendCtx.appt?.vehicle}</div>
        {sendCtx.finding.photo&&<img src={sendCtx.finding.photo} alt="constat" style={{width:'100%',maxHeight:200,objectFit:'cover',borderRadius:8,marginBottom:10}}/>}
        <div style={{fontSize:13,color:C.sub,lineHeight:1.5}}>🔧 {sendCtx.finding.desc}</div>
      </div>
      <div style={{display:'flex',flexDirection:'column',gap:10}}>
        <button onClick={sendSMS} style={{background:C.s2,border:`1px solid ${C.border}`,borderRadius:10,padding:16,display:'flex',alignItems:'center',gap:14,cursor:'pointer',width:'100%'}}>
          <span style={{fontSize:28}}>📱</span><div style={{textAlign:'left'}}><div style={{fontSize:15,fontWeight:800,color:C.text}}>SMS</div><div style={{fontSize:12,color:C.sub}}>{sendCtx.appt?.phone}</div></div>
        </button>
        <button onClick={sendEmail} style={{background:C.s2,border:`1px solid ${C.border}`,borderRadius:10,padding:16,display:'flex',alignItems:'center',gap:14,cursor:'pointer',width:'100%'}}>
          <span style={{fontSize:28}}>✉️</span><div style={{textAlign:'left'}}><div style={{fontSize:15,fontWeight:800,color:C.text}}>Courriel</div><div style={{fontSize:12,color:C.sub}}>{sendCtx.appt?.email}</div></div>
        </button>
        <Btn v='ghost' full onClick={()=>setModal(null)}>Annuler</Btn>
      </div>
    </Modal>;

    if(modal==='addTask') return <Modal title="Nouvelle tâche" onClose={()=>setModal(null)}>
      <div style={{display:'flex',flexDirection:'column',gap:12}}>
        <div><Lbl c="Description *"/><Input value={nTask.title} onChange={v=>setNT(p=>({...p,title:v}))} placeholder="Ex: Rangement pneus hiver…"/></div>
        <div><Lbl c="Catégorie"/><Sel value={nTask.cat} onChange={v=>setNT(p=>({...p,cat:v}))}>{Object.entries(TASK_CAT).map(([k,v])=><option key={k} value={k}>{v.e} {v.l}</option>)}</Sel></div>
        <div><Lbl c="Priorité"/><Sel value={nTask.prio} onChange={v=>setNT(p=>({...p,prio:v}))}><option value='high'>🔴 Haute</option><option value='medium'>🟡 Moyenne</option><option value='low'>⚪ Basse</option></Sel></div>
        <div style={{display:'flex',gap:8}}><Btn full onClick={addTask} disabled={!nTask.title}>Ajouter</Btn><Btn v='ghost' onClick={()=>setModal(null)}>Annuler</Btn></div>
      </div>
    </Modal>;

    return null;
  };

  if(!ready) return (
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:'100vh',background:C.bg,fontFamily:"'Barlow',sans-serif"}}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@900&display=swap'); @keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <div style={{fontSize:36,fontWeight:900,color:C.red,fontFamily:"'Barlow Condensed',sans-serif",letterSpacing:3}}>NAF AUTO</div>
      <div style={{marginTop:20,width:40,height:3,background:C.border,borderRadius:99,overflow:'hidden'}}>
        <div style={{height:'100%',background:C.red,borderRadius:99,animation:'load 1.2s ease-in-out infinite'}}/>
      </div>
      <style>{`@keyframes load{0%{width:0%;margin-left:0}50%{width:100%;margin-left:0}100%{width:0%;margin-left:100%}} @keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <div style={{fontSize:12,color:C.sub,marginTop:12}}>Synchronisation…</div>
    </div>
  );

  const pages = { dashboard:renderDashboard, rdv:renderRDV, atelier:renderAtelier, inspection:renderInspection, tasks:renderTasks, equipe:renderEquipe };

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100vh',background:C.bg,fontFamily:"'Barlow','DM Sans',system-ui,sans-serif",color:C.text}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Barlow:wght@400;600;700;800;900&family=Barlow+Condensed:wght@700;800;900&family=JetBrains+Mono:wght@600&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:4px;height:0} ::-webkit-scrollbar-thumb{background:#2A2B31;border-radius:3px}
        select option{background:#141519;color:#ECEDF0} textarea{font-family:inherit}
        @keyframes spin{to{transform:rotate(360deg)}}
      `}</style>

      {/* HEADER */}
      <div style={{background:C.s1,borderBottom:`1px solid ${C.border}`,flexShrink:0,position:'sticky',top:0,zIndex:50}}>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 16px 6px'}}>
          <div style={{display:'flex',alignItems:'baseline',gap:5}}>
            <span style={{fontSize:24,fontWeight:900,color:C.red,fontFamily:"'Barlow Condensed',sans-serif",letterSpacing:2,lineHeight:1}}>NAF</span>
            <span style={{fontSize:24,fontWeight:900,color:C.text,fontFamily:"'Barlow Condensed',sans-serif",letterSpacing:2,lineHeight:1}}>AUTO</span>
          </div>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            <div style={{display:'flex',alignItems:'center',gap:5}}>
              <div style={{width:7,height:7,borderRadius:'50%',background:syncing?C.amber:C.green,transition:'background .3s',boxShadow:`0 0 5px ${syncing?C.amber:C.green}`}}/>
              {lastSync&&<span style={{fontSize:10,color:C.sub,fontFamily:'monospace'}}>{lastSync}</span>}
            </div>
            {employees.filter(e=>e.status==='break').map(e=>{const b=getBreak(e.id);return b?.active?<div key={e.id} style={{background:`${C.amber}18`,border:`1px solid ${C.amber}44`,borderRadius:99,padding:'3px 9px',fontSize:11,color:C.amber,fontWeight:800,fontFamily:'monospace'}}>☕ {e.name} {fmtSec(b.active.remaining)}</div>:null;})}
            <div style={{fontSize:16,fontWeight:900,color:C.text,fontFamily:"'JetBrains Mono',monospace"}}>{now}</div>
          </div>
        </div>
        <div style={{display:'flex',gap:6,padding:'0 16px 6px',overflowX:'auto'}}>
          {[{v:freeBridges.length,l:'libres',c:C.green},{v:availableEmps.length,l:'dispos',c:C.purple},{v:readyCount,l:'prêtes',c:C.cyan},{v:activeJobs.length,l:'en cours',c:C.red}].map(s=>(
            <div key={s.l} style={{background:`${s.c}15`,border:`1px solid ${s.c}30`,borderRadius:99,padding:'3px 10px',whiteSpace:'nowrap',flexShrink:0,display:'flex',alignItems:'center',gap:5}}>
              <span style={{fontSize:13,fontWeight:900,color:s.c,fontFamily:'monospace'}}>{s.v}</span>
              <span style={{fontSize:11,color:s.c,opacity:.8}}>{s.l}</span>
            </div>
          ))}
        </div>
        <div style={{display:'flex',overflowX:'auto',borderTop:`1px solid ${C.border}`}}>
          {NAV.map(n=>{const isActive=tab===n.id,hasDot=n.id==='inspection'&&selJobId;return(
            <button key={n.id} onClick={()=>setTab(n.id)} style={{flexShrink:0,background:'transparent',border:'none',borderBottom:`2px solid ${isActive?C.red:'transparent'}`,color:isActive?C.text:C.sub,padding:'10px 16px',fontFamily:'inherit',fontSize:13,fontWeight:isActive?800:600,cursor:'pointer',display:'flex',alignItems:'center',gap:6,transition:'color .12s',whiteSpace:'nowrap',position:'relative'}}>
              <span style={{opacity:isActive?1:.5}}>{n.icon}</span>{n.label}
              {hasDot&&<span style={{width:6,height:6,background:C.red,borderRadius:'50%',position:'absolute',top:8,right:8,boxShadow:`0 0 4px ${C.red}`}}/>}
            </button>
          );})}
        </div>
      </div>

      {/* CONTENT */}
      <div style={{flex:1,overflowY:'auto',padding:14}}>
        {pages[tab]?.()}
        <div style={{height:24}}/>
      </div>

      {renderModal()}
      {dossierAppt && <DossierModal appt={dossierAppt} onClose={()=>setDA(null)} onSave={(items)=>saveDossier(dossierAppt.id,items)}/>}
      {toast && <Toast msg={toast.msg} type={toast.type}/>}
    </div>
  );
}
